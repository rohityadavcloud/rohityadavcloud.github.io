-- MySQL dump 10.13  Distrib 5.1.32, for apple-darwin9.5.0 (i386)
--
-- Host: localhost    Database: hoadis
-- ------------------------------------------------------
-- Server version	5.1.32

#Remove this#
# Get Source code at www.whatifi.undo.it #
# Copyright 2009, Rohit Yadav, Ajay Chhatwal #

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alumini`
--

DROP TABLE IF EXISTS `alumini`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `alumini` (
  `user` varchar(15) NOT NULL,
  `rno` varchar(15) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `year` int(4) NOT NULL DEFAULT '0',
  `course` varchar(20) NOT NULL,
  `aoi` varchar(100) DEFAULT NULL,
  `homepage` varchar(50) DEFAULT NULL,
  `profession` varchar(20) DEFAULT NULL,
  `desig` varchar(20) DEFAULT NULL,
  `org` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `alumini`
--

LOCK TABLES `alumini` WRITE;
/*!40000 ALTER TABLE `alumini` DISABLE KEYS */;
INSERT INTO `alumini` (`user`, `rno`, `branch`, `year`, `course`, `aoi`, `homepage`, `profession`, `desig`, `org`) VALUES ('alumini','03020002','Electronics',2007,'B.Tech.','VLSI design','','Electronics Enginner','Chief Technology Arc','NVDIA');
/*!40000 ALTER TABLE `alumini` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendBTech3101`
--

DROP TABLE IF EXISTS `attendBTech3101`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `attendBTech3101` (
  `dat` date DEFAULT NULL,
  `rno1` int(1) DEFAULT NULL,
  `rno2` int(1) DEFAULT NULL,
  `rno3` int(1) DEFAULT NULL,
  `rno4` int(1) DEFAULT NULL,
  `rno5` int(1) DEFAULT NULL,
  `rno6` int(1) DEFAULT NULL,
  `rno7` int(1) DEFAULT NULL,
  `rno8` int(1) DEFAULT NULL,
  `rno9` int(1) DEFAULT NULL,
  `rno10` int(1) DEFAULT NULL,
  `rno11` int(1) DEFAULT NULL,
  `rno12` int(1) DEFAULT NULL,
  `rno13` int(1) DEFAULT NULL,
  `rno14` int(1) DEFAULT NULL,
  `rno15` int(1) DEFAULT NULL,
  `rno16` int(1) DEFAULT NULL,
  `rno17` int(1) DEFAULT NULL,
  `rno18` int(1) DEFAULT NULL,
  `rno19` int(1) DEFAULT NULL,
  `rno20` int(1) DEFAULT NULL,
  `rno21` int(1) DEFAULT NULL,
  `rno22` int(1) DEFAULT NULL,
  `rno23` int(1) DEFAULT NULL,
  `rno24` int(1) DEFAULT NULL,
  `rno25` int(1) DEFAULT NULL,
  `rno26` int(1) DEFAULT NULL,
  `rno27` int(1) DEFAULT NULL,
  `rno28` int(1) DEFAULT NULL,
  `rno29` int(1) DEFAULT NULL,
  `rno30` int(1) DEFAULT NULL,
  `rno31` int(1) DEFAULT NULL,
  `rno32` int(1) DEFAULT NULL,
  `rno33` int(1) DEFAULT NULL,
  `rno34` int(1) DEFAULT NULL,
  `rno35` int(1) DEFAULT NULL,
  `rno36` int(1) DEFAULT NULL,
  `rno37` int(1) DEFAULT NULL,
  `rno38` int(1) DEFAULT NULL,
  `rno39` int(1) DEFAULT NULL,
  `rno40` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `attendBTech3101`
--

LOCK TABLES `attendBTech3101` WRITE;
/*!40000 ALTER TABLE `attendBTech3101` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendBTech3101` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendBTechCS2201`
--

DROP TABLE IF EXISTS `attendBTechCS2201`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `attendBTechCS2201` (
  `dat` date DEFAULT NULL,
  `rno1` int(1) DEFAULT NULL,
  `rno2` int(1) DEFAULT NULL,
  `rno3` int(1) DEFAULT NULL,
  `rno4` int(1) DEFAULT NULL,
  `rno5` int(1) DEFAULT NULL,
  `rno6` int(1) DEFAULT NULL,
  `rno7` int(1) DEFAULT NULL,
  `rno8` int(1) DEFAULT NULL,
  `rno9` int(1) DEFAULT NULL,
  `rno10` int(1) DEFAULT NULL,
  `rno11` int(1) DEFAULT NULL,
  `rno12` int(1) DEFAULT NULL,
  `rno13` int(1) DEFAULT NULL,
  `rno14` int(1) DEFAULT NULL,
  `rno15` int(1) DEFAULT NULL,
  `rno16` int(1) DEFAULT NULL,
  `rno17` int(1) DEFAULT NULL,
  `rno18` int(1) DEFAULT NULL,
  `rno19` int(1) DEFAULT NULL,
  `rno20` int(1) DEFAULT NULL,
  `rno21` int(1) DEFAULT NULL,
  `rno22` int(1) DEFAULT NULL,
  `rno23` int(1) DEFAULT NULL,
  `rno24` int(1) DEFAULT NULL,
  `rno25` int(1) DEFAULT NULL,
  `rno26` int(1) DEFAULT NULL,
  `rno27` int(1) DEFAULT NULL,
  `rno28` int(1) DEFAULT NULL,
  `rno29` int(1) DEFAULT NULL,
  `rno30` int(1) DEFAULT NULL,
  `rno31` int(1) DEFAULT NULL,
  `rno32` int(1) DEFAULT NULL,
  `rno33` int(1) DEFAULT NULL,
  `rno34` int(1) DEFAULT NULL,
  `rno35` int(1) DEFAULT NULL,
  `rno36` int(1) DEFAULT NULL,
  `rno37` int(1) DEFAULT NULL,
  `rno38` int(1) DEFAULT NULL,
  `rno39` int(1) DEFAULT NULL,
  `rno40` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `attendBTechCS2201`
--

LOCK TABLES `attendBTechCS2201` WRITE;
/*!40000 ALTER TABLE `attendBTechCS2201` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendBTechCS2201` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendBTechCS2201_old`
--

DROP TABLE IF EXISTS `attendBTechCS2201_old`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `attendBTechCS2201_old` (
  `dat` date DEFAULT NULL,
  `rno1` int(1) DEFAULT NULL,
  `rno2` int(1) DEFAULT NULL,
  `rno3` int(1) DEFAULT NULL,
  `rno4` int(1) DEFAULT NULL,
  `rno5` int(1) DEFAULT NULL,
  `rno6` int(1) DEFAULT NULL,
  `rno7` int(1) DEFAULT NULL,
  `rno8` int(1) DEFAULT NULL,
  `rno9` int(1) DEFAULT NULL,
  `rno10` int(1) DEFAULT NULL,
  `rno11` int(1) DEFAULT NULL,
  `rno12` int(1) DEFAULT NULL,
  `rno13` int(1) DEFAULT NULL,
  `rno14` int(1) DEFAULT NULL,
  `rno15` int(1) DEFAULT NULL,
  `rno16` int(1) DEFAULT NULL,
  `rno17` int(1) DEFAULT NULL,
  `rno18` int(1) DEFAULT NULL,
  `rno19` int(1) DEFAULT NULL,
  `rno20` int(1) DEFAULT NULL,
  `rno21` int(1) DEFAULT NULL,
  `rno22` int(1) DEFAULT NULL,
  `rno23` int(1) DEFAULT NULL,
  `rno24` int(1) DEFAULT NULL,
  `rno25` int(1) DEFAULT NULL,
  `rno26` int(1) DEFAULT NULL,
  `rno27` int(1) DEFAULT NULL,
  `rno28` int(1) DEFAULT NULL,
  `rno29` int(1) DEFAULT NULL,
  `rno30` int(1) DEFAULT NULL,
  `rno31` int(1) DEFAULT NULL,
  `rno32` int(1) DEFAULT NULL,
  `rno33` int(1) DEFAULT NULL,
  `rno34` int(1) DEFAULT NULL,
  `rno35` int(1) DEFAULT NULL,
  `rno36` int(1) DEFAULT NULL,
  `rno37` int(1) DEFAULT NULL,
  `rno38` int(1) DEFAULT NULL,
  `rno39` int(1) DEFAULT NULL,
  `rno40` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `attendBTechCS2201_old`
--

LOCK TABLES `attendBTechCS2201_old` WRITE;
/*!40000 ALTER TABLE `attendBTechCS2201_old` DISABLE KEYS */;
INSERT INTO `attendBTechCS2201_old` (`dat`, `rno1`, `rno2`, `rno3`, `rno4`, `rno5`, `rno6`, `rno7`, `rno8`, `rno9`, `rno10`, `rno11`, `rno12`, `rno13`, `rno14`, `rno15`, `rno16`, `rno17`, `rno18`, `rno19`, `rno20`, `rno21`, `rno22`, `rno23`, `rno24`, `rno25`, `rno26`, `rno27`, `rno28`, `rno29`, `rno30`, `rno31`, `rno32`, `rno33`, `rno34`, `rno35`, `rno36`, `rno37`, `rno38`, `rno39`, `rno40`) VALUES ('2009-04-15',1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2009-05-07',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `attendBTechCS2201_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendBTechCS2202`
--

DROP TABLE IF EXISTS `attendBTechCS2202`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `attendBTechCS2202` (
  `dat` date DEFAULT NULL,
  `rno1` int(1) DEFAULT NULL,
  `rno2` int(1) DEFAULT NULL,
  `rno3` int(1) DEFAULT NULL,
  `rno4` int(1) DEFAULT NULL,
  `rno5` int(1) DEFAULT NULL,
  `rno6` int(1) DEFAULT NULL,
  `rno7` int(1) DEFAULT NULL,
  `rno8` int(1) DEFAULT NULL,
  `rno9` int(1) DEFAULT NULL,
  `rno10` int(1) DEFAULT NULL,
  `rno11` int(1) DEFAULT NULL,
  `rno12` int(1) DEFAULT NULL,
  `rno13` int(1) DEFAULT NULL,
  `rno14` int(1) DEFAULT NULL,
  `rno15` int(1) DEFAULT NULL,
  `rno16` int(1) DEFAULT NULL,
  `rno17` int(1) DEFAULT NULL,
  `rno18` int(1) DEFAULT NULL,
  `rno19` int(1) DEFAULT NULL,
  `rno20` int(1) DEFAULT NULL,
  `rno21` int(1) DEFAULT NULL,
  `rno22` int(1) DEFAULT NULL,
  `rno23` int(1) DEFAULT NULL,
  `rno24` int(1) DEFAULT NULL,
  `rno25` int(1) DEFAULT NULL,
  `rno26` int(1) DEFAULT NULL,
  `rno27` int(1) DEFAULT NULL,
  `rno28` int(1) DEFAULT NULL,
  `rno29` int(1) DEFAULT NULL,
  `rno30` int(1) DEFAULT NULL,
  `rno31` int(1) DEFAULT NULL,
  `rno32` int(1) DEFAULT NULL,
  `rno33` int(1) DEFAULT NULL,
  `rno34` int(1) DEFAULT NULL,
  `rno35` int(1) DEFAULT NULL,
  `rno36` int(1) DEFAULT NULL,
  `rno37` int(1) DEFAULT NULL,
  `rno38` int(1) DEFAULT NULL,
  `rno39` int(1) DEFAULT NULL,
  `rno40` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `attendBTechCS2202`
--

LOCK TABLES `attendBTechCS2202` WRITE;
/*!40000 ALTER TABLE `attendBTechCS2202` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendBTechCS2202` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendBTechCS3101`
--

DROP TABLE IF EXISTS `attendBTechCS3101`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `attendBTechCS3101` (
  `dat` date DEFAULT NULL,
  `rno1` int(1) DEFAULT NULL,
  `rno2` int(1) DEFAULT NULL,
  `rno3` int(1) DEFAULT NULL,
  `rno4` int(1) DEFAULT NULL,
  `rno5` int(1) DEFAULT NULL,
  `rno6` int(1) DEFAULT NULL,
  `rno7` int(1) DEFAULT NULL,
  `rno8` int(1) DEFAULT NULL,
  `rno9` int(1) DEFAULT NULL,
  `rno10` int(1) DEFAULT NULL,
  `rno11` int(1) DEFAULT NULL,
  `rno12` int(1) DEFAULT NULL,
  `rno13` int(1) DEFAULT NULL,
  `rno14` int(1) DEFAULT NULL,
  `rno15` int(1) DEFAULT NULL,
  `rno16` int(1) DEFAULT NULL,
  `rno17` int(1) DEFAULT NULL,
  `rno18` int(1) DEFAULT NULL,
  `rno19` int(1) DEFAULT NULL,
  `rno20` int(1) DEFAULT NULL,
  `rno21` int(1) DEFAULT NULL,
  `rno22` int(1) DEFAULT NULL,
  `rno23` int(1) DEFAULT NULL,
  `rno24` int(1) DEFAULT NULL,
  `rno25` int(1) DEFAULT NULL,
  `rno26` int(1) DEFAULT NULL,
  `rno27` int(1) DEFAULT NULL,
  `rno28` int(1) DEFAULT NULL,
  `rno29` int(1) DEFAULT NULL,
  `rno30` int(1) DEFAULT NULL,
  `rno31` int(1) DEFAULT NULL,
  `rno32` int(1) DEFAULT NULL,
  `rno33` int(1) DEFAULT NULL,
  `rno34` int(1) DEFAULT NULL,
  `rno35` int(1) DEFAULT NULL,
  `rno36` int(1) DEFAULT NULL,
  `rno37` int(1) DEFAULT NULL,
  `rno38` int(1) DEFAULT NULL,
  `rno39` int(1) DEFAULT NULL,
  `rno40` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `attendBTechCS3101`
--

LOCK TABLES `attendBTechCS3101` WRITE;
/*!40000 ALTER TABLE `attendBTechCS3101` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendBTechCS3101` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `btech`
--

DROP TABLE IF EXISTS `btech`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `btech` (
  `sem` varchar(2) NOT NULL DEFAULT '',
  `lastrno` int(11) DEFAULT NULL,
  `rnoprefix` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sem`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `btech`
--

LOCK TABLES `btech` WRITE;
/*!40000 ALTER TABLE `btech` DISABLE KEYS */;
/*!40000 ALTER TABLE `btech` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courseware`
--

DROP TABLE IF EXISTS `courseware`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `courseware` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uploader` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `courseware`
--

LOCK TABLES `courseware` WRITE;
/*!40000 ALTER TABLE `courseware` DISABLE KEYS */;
INSERT INTO `courseware` (`id`, `uploader`, `filename`) VALUES (1,'Akt','back.gif'),(2,'akt','ConvexHull.java'),(3,'akt','ConvexHull.java'),(4,'akt','mess.pdf');
/*!40000 ALTER TABLE `courseware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `event` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` (`id`, `title`, `category`, `author`, `detail`, `date`) VALUES (1,'Qt Workshop','Workshop','ajay',' Qt Workshop','2009-04-10'),(2,'Seminar on Supercomputing','Seminar','ajay','Seminar on Supercomputing      ','2009-04-20'),(3,'test','Cultural Event','ry','                            \r\n                            ferfrefer','2009-05-12'),(4,'TEST','Competition','Rohit Yadav','THIS IS A TEST EVENT!','2009-04-08'),(5,'asd','Competition','asd','                            \r\n                 dasd           ','2009-07-12'),(6,'HOADIS DONE!','Other','Rohit Yadav','HOAD!S is open source: get it from:\r\nwww.whatifi.undo.it','2009-05-25'),(7,'tes','Workshop','31313232','                            \r\n        323                    ','1989-02-12');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `faculty` (
  `user` varchar(15) NOT NULL,
  `desig` varchar(255) NOT NULL,
  `qual` varchar(255) NOT NULL,
  `courses` varchar(255) NOT NULL,
  `aoi` varchar(255) DEFAULT NULL,
  `ph` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `homepage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` (`user`, `desig`, `qual`, `courses`, `aoi`, `ph`, `email`, `homepage`) VALUES ('akt','Proff','pHD','90','AI, Networks, Software Engineering','99999999','akt@bhu.ac.in','6');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gupshup`
--

DROP TABLE IF EXISTS `gupshup`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `gupshup` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `gupshup`
--

LOCK TABLES `gupshup` WRITE;
/*!40000 ALTER TABLE `gupshup` DISABLE KEYS */;
INSERT INTO `gupshup` (`id`, `author`, `msg`) VALUES (1,'akt','Testing                          '),(2,'rohit','It\'s Working!                         '),(3,'ajay','Hi all. I found a new C/C++ puzzle on whatifi.undo.it/activity                           '),(4,'rohit','After 3500 lines of Java code and more than 2000 lines of JSP/HTML, We proudly present HOAD!S                          '),(5,'akt','Hi'),(6,'rohit','ffffffffdddddrrr                      '),(7,'ajay','HI'),(8,'rohit','Hey deepesh!'),(9,'dreja','                            hii\r\n'),(10,'rohit','Ki haal chal                            '),(11,'rohit','So, height kitni hai?                         '),(12,'dreja','                            mast....tum batao'),(13,'dreja','                            its better to talk after some time....\r\n');
/*!40000 ALTER TABLE `gupshup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link`
--

DROP TABLE IF EXISTS `link`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `link` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `link`
--

LOCK TABLES `link` WRITE;
/*!40000 ALTER TABLE `link` DISABLE KEYS */;
INSERT INTO `link` (`id`, `name`, `type`, `url`) VALUES (0,'Home','E','Home'),(1,'Edit Profile','E','EditProfile'),(2,'Add Event','E','Event'),(3,'Notice Board','E','NoticeBoard'),(4,'Student Attendance','F','SelectAttendanceSubject'),(5,'Time Table','E','SelectTimeTableYear'),(6,'View Result','S','ViewResult'),(7,'Upload Courseware','F','SubCourseware'),(8,'Submit Assignment','S','SubAssign'),(9,'Download Courseware','E','DownloadCourseware'),(10,'Gupshup','E','GupShup'),(11,'Add/Edit Subjects','F','SelectSubjectToEdit');
/*!40000 ALTER TABLE `link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `login` (
  `user` varchar(15) NOT NULL,
  `pass` varchar(15) NOT NULL,
  `type` varchar(1) NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`user`, `pass`, `type`) VALUES ('','','S'),('a','a','S'),('aalumnus','aalumnus','A'),('admin','admin','X'),('ajay','ajay','S'),('akt','akt','F'),('amit','amit','S'),('ankit','ankit','S'),('astaff','astaff','G'),('astudent','astudent','S'),('ateacher','ateacher','F'),('crash','comp','S'),('dreja','dreja','S'),('faculty','faculty','F'),('harshit','harshit','S'),('hi','hi','S'),('nidhi','suryanshu','S'),('ninya','ninya','S'),('q','q','A'),('Rohit','rohit','S'),('rohit_yadav','blue19','S'),('siddhant','sid','S'),('tintin','tin','F'),('xyz','xyz','S');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `result` (
  `rno` varchar(15) NOT NULL,
  `T1` char(1) DEFAULT NULL,
  `T2` char(1) DEFAULT NULL,
  `T3` char(1) DEFAULT NULL,
  `T4` char(1) DEFAULT NULL,
  `T5` char(1) DEFAULT NULL,
  `T6` char(1) DEFAULT NULL,
  `P1` char(1) DEFAULT NULL,
  `P2` char(1) DEFAULT NULL,
  `P3` char(1) DEFAULT NULL,
  `P4` char(1) DEFAULT NULL,
  `SGPA` double(4,2) unsigned DEFAULT NULL,
  `YGPA` double(4,2) unsigned DEFAULT NULL,
  `CGPA` double(4,2) unsigned DEFAULT NULL,
  `TS1` varchar(255) DEFAULT NULL,
  `TS2` varchar(255) DEFAULT NULL,
  `TS3` varchar(255) DEFAULT NULL,
  `TS4` varchar(255) DEFAULT NULL,
  `TS5` varchar(255) DEFAULT NULL,
  `TS6` varchar(255) DEFAULT NULL,
  `PS1` varchar(255) DEFAULT NULL,
  `PS2` varchar(255) DEFAULT NULL,
  `PS3` varchar(255) DEFAULT NULL,
  `PS4` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` (`rno`, `T1`, `T2`, `T3`, `T4`, `T5`, `T6`, `P1`, `P2`, `P3`, `P4`, `SGPA`, `YGPA`, `CGPA`, `TS1`, `TS2`, `TS3`, `TS4`, `TS5`, `TS6`, `PS1`, `PS2`, `PS3`, `PS4`) VALUES ('07020002','S','S','S','S','S','S','S','S','S','S',10.00,NULL,NULL,'CS-2201','CS-2202','CS-2203','CS-2204','EC-2204','AM-2200A','CS-2401','CS-2402','CS-2403','');
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `student` (
  `user` varchar(15) NOT NULL,
  `rno` varchar(15) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `year` int(2) NOT NULL DEFAULT '0',
  `course` varchar(20) NOT NULL,
  `aoi` varchar(100) DEFAULT NULL,
  `homepage` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` (`user`, `rno`, `branch`, `year`, `course`, `aoi`, `homepage`) VALUES ('ajay','07020002','CSE',2,'B.Tech.','Algorithms,Cryptology',''),('ankit','07020012','CSE',2,'IDD','dassad,sadsa','sadsad'),('astudent','07060002','ECE',2,'B.Tech.','Microelectronics',''),('rohit','0702003','CSE',2,'IDD','Linux, OS, Interface','www.whatifi.undo.it'),('siddhant','07000035','CSE',2,'B.Tech.',NULL,NULL);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `subject` (
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(10) NOT NULL,
  `course` varchar(255) DEFAULT NULL,
  `sem` varchar(2) DEFAULT NULL,
  `teacher` varchar(255) DEFAULT NULL,
  `lastrno` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` (`name`, `code`, `course`, `sem`, `teacher`, `lastrno`) VALUES ('OS','3101','B.Tech.','5','BS',40),('Design and analysis of algorithms','CS2201','B.Tech.','4','RSS Sir',40),('Digital Circuits','CS2202','B.Tech.','4','RSS',40),('OS','CS3101','B.Tech.','5','BS',40);
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjectlist`
--

DROP TABLE IF EXISTS `subjectlist`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `subjectlist` (
  `code` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `subjectlist`
--

LOCK TABLES `subjectlist` WRITE;
/*!40000 ALTER TABLE `subjectlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `subjectlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `subjects` (
  `class` varchar(255) NOT NULL,
  `T1` varchar(255) DEFAULT NULL,
  `T2` varchar(255) DEFAULT NULL,
  `T3` varchar(255) DEFAULT NULL,
  `T4` varchar(255) DEFAULT NULL,
  `T5` varchar(255) DEFAULT NULL,
  `T6` varchar(255) DEFAULT NULL,
  `P1` varchar(255) DEFAULT NULL,
  `P2` varchar(255) DEFAULT NULL,
  `P3` varchar(255) DEFAULT NULL,
  `P4` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`class`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable1`
--

DROP TABLE IF EXISTS `timetable1`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `timetable1` (
  `id` int(11) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `mon` varchar(255) DEFAULT NULL,
  `tue` varchar(255) DEFAULT NULL,
  `wed` varchar(255) DEFAULT NULL,
  `thur` varchar(255) DEFAULT NULL,
  `fri` varchar(255) DEFAULT NULL,
  `sat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `timetable1`
--

LOCK TABLES `timetable1` WRITE;
/*!40000 ALTER TABLE `timetable1` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable2`
--

DROP TABLE IF EXISTS `timetable2`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `timetable2` (
  `id` int(11) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `mon` varchar(255) DEFAULT NULL,
  `tue` varchar(255) DEFAULT NULL,
  `wed` varchar(255) DEFAULT NULL,
  `thur` varchar(255) DEFAULT NULL,
  `fri` varchar(255) DEFAULT NULL,
  `sat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `timetable2`
--

LOCK TABLES `timetable2` WRITE;
/*!40000 ALTER TABLE `timetable2` DISABLE KEYS */;
INSERT INTO `timetable2` (`id`, `time`, `mon`, `tue`, `wed`, `thur`, `fri`, `sat`) VALUES (NULL,'8-9','VS','LP','','VS','SKS','Project Lab'),(NULL,'9-10','-','RSS','RSS','RSS','OP','Project Lab'),(NULL,'10.15-11.15','MT','RSS','RSS','OP','LP','Project Lab'),(NULL,'11.15-12.15','SKS','SKS','MT','RSS','MT','Project Lab'),(NULL,'1.30-2.30','Java Lab','-','Circuit Lab','Java Lab','','-'),(NULL,'2.30-3.30','Java Lab','-','Circuit Lab','Java Lab','','-'),(NULL,'3.30-4.30','Java Lab','-','Circuit Lab','Java Lab','','-');
/*!40000 ALTER TABLE `timetable2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable3`
--

DROP TABLE IF EXISTS `timetable3`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `timetable3` (
  `id` int(11) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `mon` varchar(255) DEFAULT NULL,
  `tue` varchar(255) DEFAULT NULL,
  `wed` varchar(255) DEFAULT NULL,
  `thur` varchar(255) DEFAULT NULL,
  `fri` varchar(255) DEFAULT NULL,
  `sat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `timetable3`
--

LOCK TABLES `timetable3` WRITE;
/*!40000 ALTER TABLE `timetable3` DISABLE KEYS */;
INSERT INTO `timetable3` (`id`, `time`, `mon`, `tue`, `wed`, `thur`, `fri`, `sat`) VALUES (NULL,'','','','','','',''),(NULL,'','','','','','',''),(NULL,'','','','','','',''),(NULL,'','','','','','',''),(NULL,'','','','','','',''),(NULL,'','','','','','',''),(NULL,'','','','','','','');
/*!40000 ALTER TABLE `timetable3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable4`
--

DROP TABLE IF EXISTS `timetable4`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `timetable4` (
  `id` int(11) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `mon` varchar(255) DEFAULT NULL,
  `tue` varchar(255) DEFAULT NULL,
  `wed` varchar(255) DEFAULT NULL,
  `thur` varchar(255) DEFAULT NULL,
  `fri` varchar(255) DEFAULT NULL,
  `sat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `timetable4`
--

LOCK TABLES `timetable4` WRITE;
/*!40000 ALTER TABLE `timetable4` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable5`
--

DROP TABLE IF EXISTS `timetable5`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `timetable5` (
  `id` int(11) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `mon` varchar(255) DEFAULT NULL,
  `tue` varchar(255) DEFAULT NULL,
  `wed` varchar(255) DEFAULT NULL,
  `thur` varchar(255) DEFAULT NULL,
  `fri` varchar(255) DEFAULT NULL,
  `sat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `timetable5`
--

LOCK TABLES `timetable5` WRITE;
/*!40000 ALTER TABLE `timetable5` DISABLE KEYS */;
/*!40000 ALTER TABLE `timetable5` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-05-11 12:07:03
