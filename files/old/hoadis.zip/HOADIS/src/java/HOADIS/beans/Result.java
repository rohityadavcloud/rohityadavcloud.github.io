package HOADIS.beans;

public class Result
{
 String rno;
 char t1,t2,t3,t4,t5,t6,p1,p2,p3,p4;
 String TS1,TS2,TS3,TS4,TS5,TS6,PS1,PS2,PS3,PS4;
 double sgpa,ygpa,cgpa;
 int sem;
 String course;

 public String getPS1()
 {
  return PS1;
 }

 public void setPS1(String PS1)
 {
  this.PS1 = PS1;
 }

 public String getPS2()
 {
  return PS2;
 }

 public void setPS2(String PS2)
 {
  this.PS2 = PS2;
 }

 public String getPS3()
 {
  return PS3;
 }

 public void setPS3(String PS3)
 {
  this.PS3 = PS3;
 }

 public String getPS4()
 {
  return PS4;
 }

 public void setPS4(String PS4)
 {
  this.PS4 = PS4;
 }

 public String getTS1()
 {
  return TS1;
 }

 public void setTS1(String TS1)
 {
  this.TS1 = TS1;
 }

 public String getTS2()
 {
  return TS2;
 }

 public void setTS2(String TS2)
 {
  this.TS2 = TS2;
 }

 public String getTS3()
 {
  return TS3;
 }

 public void setTS3(String TS3)
 {
  this.TS3 = TS3;
 }

 public String getTS4()
 {
  return TS4;
 }

 public void setTS4(String TS4)
 {
  this.TS4 = TS4;
 }

 public String getTS5()
 {
  return TS5;
 }

 public void setTS5(String TS5)
 {
  this.TS5 = TS5;
 }

 public String getTS6()
 {
  return TS6;
 }

 public void setTS6(String TS6)
 {
  this.TS6 = TS6;
 }

 public double getCgpa()
 {
  return cgpa;
 }

 public void setCgpa(double cgpa)
 {
  this.cgpa = cgpa;
 }

 public String getCourse()
 {
  return course;
 }

 public void setCourse(String course)
 {
  this.course = course;
 }

 public char getP1()
 {
  return p1;
 }

 public void setP1(char p1)
 {
  this.p1 = p1;
 }

 public char getP2()
 {
  return p2;
 }

 public void setP2(char p2)
 {
  this.p2 = p2;
 }

 public char getP3()
 {
  return p3;
 }

 public void setP3(char p3)
 {
  this.p3 = p3;
 }

 public char getP4()
 {
  return p4;
 }

 public void setP4(char p4)
 {
  this.p4 = p4;
 }

 public String getRno()
 {
  return rno;
 }

 public void setRno(String rno)
 {
  this.rno = rno;
 }

 public int getSem()
 {
  return sem;
 }

 public void setSem(int sem)
 {
  this.sem = sem;
 }

 public double getSgpa()
 {
  return sgpa;
 }

 public void setSgpa(double sgpa)
 {
  this.sgpa = sgpa;
 }

 public char getT1()
 {
  return t1;
 }

 public void setT1(char t1)
 {
  this.t1 = t1;
 }

 public char getT2()
 {
  return t2;
 }

 public void setT2(char t2)
 {
  this.t2 = t2;
 }

 public char getT3()
 {
  return t3;
 }

 public void setT3(char t3)
 {
  this.t3 = t3;
 }

 public char getT4()
 {
  return t4;
 }

 public void setT4(char t4)
 {
  this.t4 = t4;
 }

 public char getT5()
 {
  return t5;
 }

 public void setT5(char t5)
 {
  this.t5 = t5;
 }

 public char getT6()
 {
  return t6;
 }

 public void setT6(char t6)
 {
  this.t6 = t6;
 }

 public double getYgpa()
 {
  return ygpa;
 }

 public void setYgpa(double ygpa)
 {
  this.ygpa = ygpa;
 }

 
 
}
