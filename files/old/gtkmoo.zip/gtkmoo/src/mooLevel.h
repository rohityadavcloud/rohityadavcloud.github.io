/*
 *  mooLevel.h
 *  GtkMoo
 *
 *  Created by Rohit Yadav on 10/10/08.
 *  Copyright 2008-10 Rohit Yadav.
 *
 */

#ifndef _MOO_LEVEL_
#define _MOO_LEVEL_

gint* mooLevelSettings(GtkMenuItem *menuitem, gint* LEVEL);

#endif
