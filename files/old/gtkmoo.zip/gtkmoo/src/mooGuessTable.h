/*
 *  mooGuessTable.h
 *  GtkMoo
 *
 *  Created by Rohit Yadav on 10/10/08.
 *  Copyright 2008-10 Rohit Yadav.
 *
 */

#ifndef _MOO_GT_
#define _MOO_GT_

#include <gtk/gtk.h>

void mooGuessTable(GtkWidget* mooVbox);
void initTable(GtkWidget* mooVbox);

#endif
