/*
 *  mooToolBar.h
 *  GtkMoo
 *
 *  Created by Rohit Yadav on 10/10/08.
 *  Copyright 2008-10 Rohit Yadav.
 *
 */

#ifndef _MOO_TB_
#define _MOO_TB_

void init_Settings (GtkMenuItem *menuitem, gpointer user_data);
void init_new (GtkMenuItem *menuitem, gpointer user_data);
GtkWidget* mooToolBar (void);

#endif
