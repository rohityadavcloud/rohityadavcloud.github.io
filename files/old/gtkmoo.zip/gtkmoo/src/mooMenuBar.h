/*
 *  mooMenuBar.h
 *  GtkMoo
 *
 *  Created by Rohit Yadav on 10/10/08.
 *  Copyright 2008-10 Rohit Yadav.
 *
 */

#ifndef _MOO_MENUBAR_
#define _MOO_MENUBAR_

GtkWidget* mooMenuBar (GtkWidget* window);

#endif
