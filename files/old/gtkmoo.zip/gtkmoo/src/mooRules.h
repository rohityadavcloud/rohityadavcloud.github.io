/*
 *  mooRules.h
 *  GtkMoo
 *
 *  Created by Rohit Yadav on 10/10/08.
 *  Copyright 2008-10 Rohit Yadav.
 *
 */

#ifndef _MOO_RULES_
#define _MOO_RULES_

#include <stdio.h>
#include <gtk/gtk.h>

void mooRules(GtkMenuItem *menuitem, gpointer user_data);

#endif
