/*
 *  mooAbout.h
 *  GtkMoo
 *
 *  Copyright 2008-10 Rohit Yadav.
 *
 */

#ifndef _MOO_ABOUT_
#define _MOO_ABOUT_

GtkWidget* aboutGtkMoo (void);

#endif
