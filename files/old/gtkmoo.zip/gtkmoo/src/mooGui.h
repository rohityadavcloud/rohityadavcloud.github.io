/*
 *  mooGui.h
 *  GtkMoo
 *
 *  Created by Rohit Yadav on 10/10/08.
 *  Copyright 2008-10 Rohit Yadav.
 *
 */

#ifndef _MOO_GUI_
#define _MOO_GUI_

GtkWidget* create_mooWindow (void);

#endif
