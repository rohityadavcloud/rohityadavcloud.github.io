# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Quizapp::Application.config.secret_token = '7e5fb9a7e5bad38d30a495bc5d91216f29247c2bee90147581a13ece36f6c636f00e4b1dd508fd036f37738fe3956f6456345e3e89ec9449859f2d5757b5b870'
