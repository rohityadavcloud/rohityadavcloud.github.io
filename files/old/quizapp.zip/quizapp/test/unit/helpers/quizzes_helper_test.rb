require 'test_helper'

class QuizzesHelperTest < ActionView::TestCase
end
