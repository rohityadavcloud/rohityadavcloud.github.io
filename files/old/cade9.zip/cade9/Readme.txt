CADE9 is a project of task sch. and learning atmega uCs. And a small ping-pong game on it.

Just 4 fun!
Rohit Yadav