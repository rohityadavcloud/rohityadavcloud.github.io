#ifndef CLOCK_H
#define CLOCK_H

#include <inttypes.h>

void clock_init(uint32_t tick_ms);

#endif
