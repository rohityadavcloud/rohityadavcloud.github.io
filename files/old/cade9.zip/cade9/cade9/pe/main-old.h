#ifndef MAIN_H
#define MAIN_H


#include "cocoos.h"


extern os_event_type evRacketMove;

#endif
