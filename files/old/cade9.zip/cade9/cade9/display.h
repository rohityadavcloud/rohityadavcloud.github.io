#ifndef BALL_H
#define BALL_H

#include "cocoos.h"




#endif
