///////////////////////////////////////////////////////////////////////////////
// smileys.h
// IceCuBe Smileys: Taken from ShakesPeer :-)
//
// © Rohit Yadav, 2008-2009.
// SOME RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////

// cool B-)
// cry :(
// happy :-D
// hmm :-/
// sad :-(
// smile :-)
// wink ;-)
// yawn :Zz

#ifndef SMILEY_H
#define SMILEY_H

#include "smileys/cool.h"  //B-)
#include "smileys/cry.h"   //:(
#include "smileys/happy.h" //:-D
#include "smileys/hmm.h"   //:-/
#include "smileys/sad.h"   //:-(
#include "smileys/smile.h" //:-)
#include "smileys/wink.h"  //;-)
#include "smileys/yawn.h"  //:Zz

enum
{ 
  cool,
  cry,
  happy,
  hmm,
  sad,
  smile,
  wink,
  yawn
};

#endif
