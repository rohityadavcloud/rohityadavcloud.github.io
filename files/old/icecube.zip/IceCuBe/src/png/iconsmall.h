///////////////////////////////////////////////////////////////////////////////
// iconbig.h
// IceCuBe SmallIcons: Taken from Variable sources, 
// main icon/logos made by Rohit Yadav
// Size: 16x16 px
//
// © Rohit Yadav, 2008-2009.
// SOME RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////

#ifndef ICONS_SMALL_H
#define ICONS_SMALL_H

#include "small/admin.h"
#include "small/attach.h"
#include "small/availablesmall.h"
#include "small/busysmall.h"
#include "small/customsmall.h"
#include "small/ipmsg.h"
#include "small/public.h"
#include "small/user.h"

enum
{
  admin,
  attach,
  availablesmall,
  busysmall,
  customsmall,
  ipmsg,
  iconpublic,
  user
};

#endif
