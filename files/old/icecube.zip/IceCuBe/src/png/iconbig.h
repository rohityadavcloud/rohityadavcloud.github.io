///////////////////////////////////////////////////////////////////////////////
// iconbig.h
// IceCuBe BigIcons: Taken from Variable sources, 
// main icon/logos made by Rohit Yadav
// Size: 32x32 px
//
// © Rohit Yadav, 2008-2009.
// SOME RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////

#ifndef ICONS_BIG_H
#define ICONS_BIG_H

#include "big/available.h" //Toolbar
#include "big/banner.h"    //TB optional
#include "big/busy.h"      //ToolB
#include "big/close.h"     //For downloads started...receiveing box(packets)
#include "big/configure.h" //TB
#include "big/connect.h"   //TB
#include "big/cube.h"      //TB opt
#include "big/custom.h"
#include "big/icon.h"      //TB opt
#include "big/ipmsgbig.h"
#include "big/mic.h"       //for VoIP
#include "big/open.h"      //For down finshed
#include "big/record.h"
#include "big/refresh.h"    //TB
#include "big/separator.h"  //TB
#include "big/tree.h"       //TB
#include "big/userbig.h"
#include "big/userlistoff.h"//TB
#include "big/userliston.h" //TB
#include "big/usermic.h"    //TB
#include "big/video.h"      //For Video Chat

#include "tux.h"

//Enum for TB
enum
{
  newmsg,
  refresh,
  connectpeer,
  busy,
  available,
  showlist,
  hidelist,
  separator,
  preferences,
  about,
  quit
};

#endif
