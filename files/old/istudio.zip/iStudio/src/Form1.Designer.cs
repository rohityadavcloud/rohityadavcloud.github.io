﻿namespace Eniac
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.image1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.image2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.image3forWallpaperXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filtersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.twoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addImagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subtractImagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold0ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold20ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold30ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold40ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold50ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wallpaperChangesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grayscaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thresholdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cropToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.histpgramEqualizationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cleanerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.flipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verticallyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontallyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rotateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripSplitButton();
            this.image1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.image2ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.image3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.mergeImages12ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.differenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold0ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold10ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold20ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold30ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold40ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.threshold50ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.wallpaperXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.flipToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.verticallyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontallyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rotate90DegreesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resizeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.halfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quarterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Silver;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.filtersToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(992, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.newToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.newToolStripMenuItem.Text = "&Reload ";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.image1ToolStripMenuItem1,
            this.image2ToolStripMenuItem1,
            this.image3forWallpaperXToolStripMenuItem});
            this.openToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem.Image")));
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // image1ToolStripMenuItem1
            // 
            this.image1ToolStripMenuItem1.Name = "image1ToolStripMenuItem1";
            this.image1ToolStripMenuItem1.Size = new System.Drawing.Size(219, 22);
            this.image1ToolStripMenuItem1.Text = "Image 1";
            this.image1ToolStripMenuItem1.Click += new System.EventHandler(this.image1ToolStripMenuItem1_Click);
            // 
            // image2ToolStripMenuItem1
            // 
            this.image2ToolStripMenuItem1.Name = "image2ToolStripMenuItem1";
            this.image2ToolStripMenuItem1.Size = new System.Drawing.Size(219, 22);
            this.image2ToolStripMenuItem1.Text = "Image 2 (for 2 image filters)";
            this.image2ToolStripMenuItem1.Click += new System.EventHandler(this.image2ToolStripMenuItem1_Click);
            // 
            // image3forWallpaperXToolStripMenuItem
            // 
            this.image3forWallpaperXToolStripMenuItem.Name = "image3forWallpaperXToolStripMenuItem";
            this.image3forWallpaperXToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.image3forWallpaperXToolStripMenuItem.Text = "Image 3 (for WallpaperX)";
            this.image3forWallpaperXToolStripMenuItem.Click += new System.EventHandler(this.image3forWallpaperXToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveAsToolStripMenuItem.Image")));
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.saveAsToolStripMenuItem.Text = "&Save As...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // filtersToolStripMenuItem
            // 
            this.filtersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.twoToolStripMenuItem,
            this.grayscaleToolStripMenuItem,
            this.thresholdToolStripMenuItem,
            this.cropToolStripMenuItem,
            this.histpgramEqualizationToolStripMenuItem,
            this.cleanerToolStripMenuItem,
            this.toolStripSeparator5,
            this.flipToolStripMenuItem,
            this.rotateToolStripMenuItem,
            this.resizeToolStripMenuItem});
            this.filtersToolStripMenuItem.Name = "filtersToolStripMenuItem";
            this.filtersToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.filtersToolStripMenuItem.Text = "&Tools";
            // 
            // twoToolStripMenuItem
            // 
            this.twoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addImagesToolStripMenuItem,
            this.subtractImagesToolStripMenuItem,
            this.wallpaperChangesToolStripMenuItem});
            this.twoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("twoToolStripMenuItem.Image")));
            this.twoToolStripMenuItem.Name = "twoToolStripMenuItem";
            this.twoToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.twoToolStripMenuItem.Text = " 2 Source Filters";
            // 
            // addImagesToolStripMenuItem
            // 
            this.addImagesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addImagesToolStripMenuItem.Image")));
            this.addImagesToolStripMenuItem.Name = "addImagesToolStripMenuItem";
            this.addImagesToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.addImagesToolStripMenuItem.Text = "Merge";
            this.addImagesToolStripMenuItem.Click += new System.EventHandler(this.addImagesToolStripMenuItem_Click);
            // 
            // subtractImagesToolStripMenuItem
            // 
            this.subtractImagesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.threshold0ToolStripMenuItem,
            this.threshold10ToolStripMenuItem,
            this.threshold20ToolStripMenuItem,
            this.threshold30ToolStripMenuItem,
            this.threshold40ToolStripMenuItem,
            this.threshold50ToolStripMenuItem});
            this.subtractImagesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("subtractImagesToolStripMenuItem.Image")));
            this.subtractImagesToolStripMenuItem.Name = "subtractImagesToolStripMenuItem";
            this.subtractImagesToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.subtractImagesToolStripMenuItem.Text = "Difference";
            this.subtractImagesToolStripMenuItem.Click += new System.EventHandler(this.subtractImagesToolStripMenuItem_Click);
            // 
            // threshold0ToolStripMenuItem
            // 
            this.threshold0ToolStripMenuItem.Name = "threshold0ToolStripMenuItem";
            this.threshold0ToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.threshold0ToolStripMenuItem.Text = "Threshold 0";
            this.threshold0ToolStripMenuItem.Click += new System.EventHandler(this.threshold0ToolStripMenuItem_Click);
            // 
            // threshold10ToolStripMenuItem
            // 
            this.threshold10ToolStripMenuItem.Name = "threshold10ToolStripMenuItem";
            this.threshold10ToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.threshold10ToolStripMenuItem.Text = "Threshold 10";
            this.threshold10ToolStripMenuItem.Click += new System.EventHandler(this.threshold10ToolStripMenuItem_Click);
            // 
            // threshold20ToolStripMenuItem
            // 
            this.threshold20ToolStripMenuItem.Name = "threshold20ToolStripMenuItem";
            this.threshold20ToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.threshold20ToolStripMenuItem.Text = "Threshold 20";
            this.threshold20ToolStripMenuItem.Click += new System.EventHandler(this.threshold20ToolStripMenuItem_Click);
            // 
            // threshold30ToolStripMenuItem
            // 
            this.threshold30ToolStripMenuItem.Name = "threshold30ToolStripMenuItem";
            this.threshold30ToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.threshold30ToolStripMenuItem.Text = "Threshold 30";
            this.threshold30ToolStripMenuItem.Click += new System.EventHandler(this.threshold30ToolStripMenuItem_Click);
            // 
            // threshold40ToolStripMenuItem
            // 
            this.threshold40ToolStripMenuItem.Name = "threshold40ToolStripMenuItem";
            this.threshold40ToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.threshold40ToolStripMenuItem.Text = "Threshold 40";
            this.threshold40ToolStripMenuItem.Click += new System.EventHandler(this.threshold40ToolStripMenuItem_Click);
            // 
            // threshold50ToolStripMenuItem
            // 
            this.threshold50ToolStripMenuItem.Name = "threshold50ToolStripMenuItem";
            this.threshold50ToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.threshold50ToolStripMenuItem.Text = "Threshold 50";
            this.threshold50ToolStripMenuItem.Click += new System.EventHandler(this.threshold50ToolStripMenuItem_Click);
            // 
            // wallpaperChangesToolStripMenuItem
            // 
            this.wallpaperChangesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("wallpaperChangesToolStripMenuItem.Image")));
            this.wallpaperChangesToolStripMenuItem.Name = "wallpaperChangesToolStripMenuItem";
            this.wallpaperChangesToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.wallpaperChangesToolStripMenuItem.Text = "WallpaperX";
            this.wallpaperChangesToolStripMenuItem.Click += new System.EventHandler(this.wallpaperChangesToolStripMenuItem_Click);
            // 
            // grayscaleToolStripMenuItem
            // 
            this.grayscaleToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("grayscaleToolStripMenuItem.Image")));
            this.grayscaleToolStripMenuItem.Name = "grayscaleToolStripMenuItem";
            this.grayscaleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.grayscaleToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.grayscaleToolStripMenuItem.Text = "Gray&scale";
            this.grayscaleToolStripMenuItem.Click += new System.EventHandler(this.grayscaleToolStripMenuItem_Click);
            // 
            // thresholdToolStripMenuItem
            // 
            this.thresholdToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thresholdToolStripMenuItem.Image")));
            this.thresholdToolStripMenuItem.Name = "thresholdToolStripMenuItem";
            this.thresholdToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.thresholdToolStripMenuItem.Text = "&Threshold(Binarization)";
            this.thresholdToolStripMenuItem.Click += new System.EventHandler(this.thresholdToolStripMenuItem_Click);
            // 
            // cropToolStripMenuItem
            // 
            this.cropToolStripMenuItem.Name = "cropToolStripMenuItem";
            this.cropToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.cropToolStripMenuItem.Text = "Sepia";
            this.cropToolStripMenuItem.Click += new System.EventHandler(this.cropToolStripMenuItem_Click);
            // 
            // histpgramEqualizationToolStripMenuItem
            // 
            this.histpgramEqualizationToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("histpgramEqualizationToolStripMenuItem.Image")));
            this.histpgramEqualizationToolStripMenuItem.Name = "histpgramEqualizationToolStripMenuItem";
            this.histpgramEqualizationToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.histpgramEqualizationToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.histpgramEqualizationToolStripMenuItem.Text = "&Invert";
            this.histpgramEqualizationToolStripMenuItem.Click += new System.EventHandler(this.histpgramEqualizationToolStripMenuItem_Click);
            // 
            // cleanerToolStripMenuItem
            // 
            this.cleanerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.greenToolStripMenuItem,
            this.redToolStripMenuItem,
            this.blueToolStripMenuItem});
            this.cleanerToolStripMenuItem.Name = "cleanerToolStripMenuItem";
            this.cleanerToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.cleanerToolStripMenuItem.Text = "Tint";
            this.cleanerToolStripMenuItem.Click += new System.EventHandler(this.cleanerToolStripMenuItem_Click);
            // 
            // greenToolStripMenuItem
            // 
            this.greenToolStripMenuItem.Name = "greenToolStripMenuItem";
            this.greenToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.greenToolStripMenuItem.Text = "Green";
            this.greenToolStripMenuItem.Click += new System.EventHandler(this.greenToolStripMenuItem_Click);
            // 
            // redToolStripMenuItem
            // 
            this.redToolStripMenuItem.Name = "redToolStripMenuItem";
            this.redToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.redToolStripMenuItem.Text = "Red";
            this.redToolStripMenuItem.Click += new System.EventHandler(this.redToolStripMenuItem_Click);
            // 
            // blueToolStripMenuItem
            // 
            this.blueToolStripMenuItem.Name = "blueToolStripMenuItem";
            this.blueToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.blueToolStripMenuItem.Text = "Blue";
            this.blueToolStripMenuItem.Click += new System.EventHandler(this.blueToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(224, 6);
            // 
            // flipToolStripMenuItem
            // 
            this.flipToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verticallyToolStripMenuItem,
            this.horizontallyToolStripMenuItem});
            this.flipToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("flipToolStripMenuItem.Image")));
            this.flipToolStripMenuItem.Name = "flipToolStripMenuItem";
            this.flipToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.flipToolStripMenuItem.Text = "Flip";
            this.flipToolStripMenuItem.Click += new System.EventHandler(this.flipToolStripMenuItem_Click);
            // 
            // verticallyToolStripMenuItem
            // 
            this.verticallyToolStripMenuItem.Name = "verticallyToolStripMenuItem";
            this.verticallyToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.verticallyToolStripMenuItem.Text = "Vertically";
            this.verticallyToolStripMenuItem.Click += new System.EventHandler(this.verticallyToolStripMenuItem_Click);
            // 
            // horizontallyToolStripMenuItem
            // 
            this.horizontallyToolStripMenuItem.Name = "horizontallyToolStripMenuItem";
            this.horizontallyToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.horizontallyToolStripMenuItem.Text = "Horizontally";
            this.horizontallyToolStripMenuItem.Click += new System.EventHandler(this.horizontallyToolStripMenuItem_Click);
            // 
            // rotateToolStripMenuItem
            // 
            this.rotateToolStripMenuItem.Name = "rotateToolStripMenuItem";
            this.rotateToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.rotateToolStripMenuItem.Text = "Rotate 90 degrees(clockwise)";
            this.rotateToolStripMenuItem.Click += new System.EventHandler(this.rotateToolStripMenuItem_Click);
            // 
            // resizeToolStripMenuItem
            // 
            this.resizeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.resizeToolStripMenuItem.Name = "resizeToolStripMenuItem";
            this.resizeToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.resizeToolStripMenuItem.Text = "Resize";
            this.resizeToolStripMenuItem.Click += new System.EventHandler(this.resizeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.toolStripMenuItem1.Text = "Half Size";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click_1);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(145, 22);
            this.toolStripMenuItem2.Text = "Quarter Size";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click_1);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem1});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.aboutToolStripMenuItem.Text = "&Help";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("aboutToolStripMenuItem1.Image")));
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.aboutToolStripMenuItem1.Text = "&About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripSplitButton1,
            this.toolStripDropDownButton1,
            this.toolStripSeparator3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton8,
            this.toolStripButton6,
            this.toolStripLabel8,
            this.toolStripSeparator1,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Margin = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.toolStrip1.MinimumSize = new System.Drawing.Size(0, 25);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(992, 25);
            this.toolStrip1.Stretch = true;
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "Tool Strip";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.image1ToolStripMenuItem2,
            this.image2ToolStripMenuItem2,
            this.image3ToolStripMenuItem});
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(32, 22);
            this.toolStripButton3.Text = "Open";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            this.toolStripButton3.ButtonClick += new System.EventHandler(this.toolStripButton3_ButtonClick);
            // 
            // image1ToolStripMenuItem2
            // 
            this.image1ToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("image1ToolStripMenuItem2.Image")));
            this.image1ToolStripMenuItem2.Name = "image1ToolStripMenuItem2";
            this.image1ToolStripMenuItem2.Size = new System.Drawing.Size(127, 22);
            this.image1ToolStripMenuItem2.Text = "Image &1";
            this.image1ToolStripMenuItem2.Click += new System.EventHandler(this.image1ToolStripMenuItem2_Click);
            // 
            // image2ToolStripMenuItem2
            // 
            this.image2ToolStripMenuItem2.Name = "image2ToolStripMenuItem2";
            this.image2ToolStripMenuItem2.Size = new System.Drawing.Size(127, 22);
            this.image2ToolStripMenuItem2.Text = "Image &2";
            this.image2ToolStripMenuItem2.Click += new System.EventHandler(this.image2ToolStripMenuItem2_Click);
            // 
            // image3ToolStripMenuItem
            // 
            this.image3ToolStripMenuItem.Name = "image3ToolStripMenuItem";
            this.image3ToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.image3ToolStripMenuItem.Text = "Image &3 ";
            this.image3ToolStripMenuItem.Click += new System.EventHandler(this.image3ToolStripMenuItem_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "Save As";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click_1);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "Reload Image";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mergeImages12ToolStripMenuItem,
            this.differenceToolStripMenuItem,
            this.wallpaperXToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton1.Text = "2 Source Filters";
            this.toolStripSplitButton1.ButtonClick += new System.EventHandler(this.toolStripSplitButton1_ButtonClick);
            // 
            // mergeImages12ToolStripMenuItem
            // 
            this.mergeImages12ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("mergeImages12ToolStripMenuItem.Image")));
            this.mergeImages12ToolStripMenuItem.Name = "mergeImages12ToolStripMenuItem";
            this.mergeImages12ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.mergeImages12ToolStripMenuItem.Text = "Merge Images";
            this.mergeImages12ToolStripMenuItem.Click += new System.EventHandler(this.mergeImages12ToolStripMenuItem_Click);
            // 
            // differenceToolStripMenuItem
            // 
            this.differenceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.threshold0ToolStripMenuItem1,
            this.threshold10ToolStripMenuItem1,
            this.threshold20ToolStripMenuItem1,
            this.threshold30ToolStripMenuItem1,
            this.threshold40ToolStripMenuItem1,
            this.threshold50ToolStripMenuItem1});
            this.differenceToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("differenceToolStripMenuItem.Image")));
            this.differenceToolStripMenuItem.Name = "differenceToolStripMenuItem";
            this.differenceToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.differenceToolStripMenuItem.Text = "Difference";
            this.differenceToolStripMenuItem.Click += new System.EventHandler(this.differenceToolStripMenuItem_Click);
            // 
            // threshold0ToolStripMenuItem1
            // 
            this.threshold0ToolStripMenuItem1.Name = "threshold0ToolStripMenuItem1";
            this.threshold0ToolStripMenuItem1.Size = new System.Drawing.Size(147, 22);
            this.threshold0ToolStripMenuItem1.Text = "Threshold 0";
            this.threshold0ToolStripMenuItem1.Click += new System.EventHandler(this.threshold0ToolStripMenuItem1_Click);
            // 
            // threshold10ToolStripMenuItem1
            // 
            this.threshold10ToolStripMenuItem1.Name = "threshold10ToolStripMenuItem1";
            this.threshold10ToolStripMenuItem1.Size = new System.Drawing.Size(147, 22);
            this.threshold10ToolStripMenuItem1.Text = "Threshold 10";
            this.threshold10ToolStripMenuItem1.Click += new System.EventHandler(this.threshold10ToolStripMenuItem1_Click);
            // 
            // threshold20ToolStripMenuItem1
            // 
            this.threshold20ToolStripMenuItem1.Name = "threshold20ToolStripMenuItem1";
            this.threshold20ToolStripMenuItem1.Size = new System.Drawing.Size(147, 22);
            this.threshold20ToolStripMenuItem1.Text = "Threshold 20";
            this.threshold20ToolStripMenuItem1.Click += new System.EventHandler(this.threshold20ToolStripMenuItem1_Click);
            // 
            // threshold30ToolStripMenuItem1
            // 
            this.threshold30ToolStripMenuItem1.Name = "threshold30ToolStripMenuItem1";
            this.threshold30ToolStripMenuItem1.Size = new System.Drawing.Size(147, 22);
            this.threshold30ToolStripMenuItem1.Text = "Threshold 30";
            this.threshold30ToolStripMenuItem1.Click += new System.EventHandler(this.threshold30ToolStripMenuItem1_Click);
            // 
            // threshold40ToolStripMenuItem1
            // 
            this.threshold40ToolStripMenuItem1.Name = "threshold40ToolStripMenuItem1";
            this.threshold40ToolStripMenuItem1.Size = new System.Drawing.Size(147, 22);
            this.threshold40ToolStripMenuItem1.Text = "Threshold 40";
            this.threshold40ToolStripMenuItem1.Click += new System.EventHandler(this.threshold40ToolStripMenuItem1_Click);
            // 
            // threshold50ToolStripMenuItem1
            // 
            this.threshold50ToolStripMenuItem1.Name = "threshold50ToolStripMenuItem1";
            this.threshold50ToolStripMenuItem1.Size = new System.Drawing.Size(147, 22);
            this.threshold50ToolStripMenuItem1.Text = "Threshold 50";
            this.threshold50ToolStripMenuItem1.Click += new System.EventHandler(this.threshold50ToolStripMenuItem1_Click);
            // 
            // wallpaperXToolStripMenuItem
            // 
            this.wallpaperXToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("wallpaperXToolStripMenuItem.Image")));
            this.wallpaperXToolStripMenuItem.Name = "wallpaperXToolStripMenuItem";
            this.wallpaperXToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.wallpaperXToolStripMenuItem.Text = "WallpaperX";
            this.wallpaperXToolStripMenuItem.Click += new System.EventHandler(this.wallpaperXToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.flipToolStripMenuItem1,
            this.rotate90DegreesToolStripMenuItem,
            this.resizeToolStripMenuItem1});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "Common Tools";
            // 
            // flipToolStripMenuItem1
            // 
            this.flipToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verticallyToolStripMenuItem1,
            this.horizontallyToolStripMenuItem1});
            this.flipToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("flipToolStripMenuItem1.Image")));
            this.flipToolStripMenuItem1.Name = "flipToolStripMenuItem1";
            this.flipToolStripMenuItem1.Size = new System.Drawing.Size(175, 22);
            this.flipToolStripMenuItem1.Text = "Flip";
            // 
            // verticallyToolStripMenuItem1
            // 
            this.verticallyToolStripMenuItem1.Name = "verticallyToolStripMenuItem1";
            this.verticallyToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.verticallyToolStripMenuItem1.Text = "Vertically";
            this.verticallyToolStripMenuItem1.Click += new System.EventHandler(this.verticallyToolStripMenuItem1_Click);
            // 
            // horizontallyToolStripMenuItem1
            // 
            this.horizontallyToolStripMenuItem1.Name = "horizontallyToolStripMenuItem1";
            this.horizontallyToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.horizontallyToolStripMenuItem1.Text = "Horizontally";
            this.horizontallyToolStripMenuItem1.Click += new System.EventHandler(this.horizontallyToolStripMenuItem1_Click);
            // 
            // rotate90DegreesToolStripMenuItem
            // 
            this.rotate90DegreesToolStripMenuItem.Name = "rotate90DegreesToolStripMenuItem";
            this.rotate90DegreesToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.rotate90DegreesToolStripMenuItem.Text = "Rotate 90 degrees";
            this.rotate90DegreesToolStripMenuItem.Click += new System.EventHandler(this.rotate90DegreesToolStripMenuItem_Click);
            // 
            // resizeToolStripMenuItem1
            // 
            this.resizeToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.halfToolStripMenuItem,
            this.quarterToolStripMenuItem,
            this.toolStripMenuItem4});
            this.resizeToolStripMenuItem1.Name = "resizeToolStripMenuItem1";
            this.resizeToolStripMenuItem1.Size = new System.Drawing.Size(175, 22);
            this.resizeToolStripMenuItem1.Text = "Resize";
            // 
            // halfToolStripMenuItem
            // 
            this.halfToolStripMenuItem.Name = "halfToolStripMenuItem";
            this.halfToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.halfToolStripMenuItem.Text = "Half";
            this.halfToolStripMenuItem.Click += new System.EventHandler(this.halfToolStripMenuItem_Click);
            // 
            // quarterToolStripMenuItem
            // 
            this.quarterToolStripMenuItem.Name = "quarterToolStripMenuItem";
            this.quarterToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.quarterToolStripMenuItem.Text = "Quarter";
            this.quarterToolStripMenuItem.Click += new System.EventHandler(this.quarterToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(123, 22);
            this.toolStripMenuItem4.Text = "1/8";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Grayscale";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Threshold";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton8.Text = "Sepia";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Invert";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(0, 22);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton7.Text = "About";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox1.Location = new System.Drawing.Point(6, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(948, 546);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.WaitOnLoad = true;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.Gray;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 651);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(992, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(38, 17);
            this.toolStripStatusLabel1.Text = "Status";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.BackColor = System.Drawing.Color.Silver;
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(200, 16);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 17);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 61);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(968, 584);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Gray;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(960, 558);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Image 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Gray;
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(960, 558);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Image 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox2.Location = new System.Drawing.Point(6, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(948, 546);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.WaitOnLoad = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Gray;
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(960, 558);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Image 3::WallaperX";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox3.Location = new System.Drawing.Point(6, 6);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(948, 546);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.WaitOnLoad = true;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(799, 653);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(181, 20);
            this.textBox1.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(992, 673);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "iStudio 2.10 :: Basic IP Tool";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filtersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem grayscaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem histpgramEqualizationToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripLabel toolStripLabel8;
        private System.Windows.Forms.ToolStripMenuItem thresholdToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripMenuItem flipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verticallyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horizontallyToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem flipToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem verticallyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem horizontallyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem rotateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cropToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem twoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addImagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subtractImagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cleanerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem image1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem image2ToolStripMenuItem1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripSplitButton toolStripButton3;
        private System.Windows.Forms.ToolStripMenuItem image1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem image2ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem rotate90DegreesToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem mergeImages12ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem differenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem resizeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem halfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quarterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem greenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wallpaperChangesToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ToolStripMenuItem image3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wallpaperXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem image3forWallpaperXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threshold10ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threshold20ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threshold30ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threshold40ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threshold0ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threshold0ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem threshold10ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem threshold20ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem threshold30ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem threshold40ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem threshold50ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem threshold50ToolStripMenuItem1;
    }
}

